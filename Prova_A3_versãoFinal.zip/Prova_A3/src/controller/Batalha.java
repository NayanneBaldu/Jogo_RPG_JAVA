package controller;

import model.Inimigo;
import model.Jogador;

public class Batalha {

    private Jogador jogador;
    private Inimigo inimigo;

    public Batalha(Jogador jogador, Inimigo inimigo) {
        this.jogador = jogador;
        this.inimigo = inimigo;
    }

    
    public int turnoJogador() {
        int dano = jogador.atacar(inimigo);
        return dano;
    }

    public int turnoInimigo() {
        int dano = inimigo.atacar();
        jogador.receberDano(dano);
        return dano;
    }

    public boolean inimigoMorreu() {
        return !inimigo.estaVivo();
    }

    public boolean jogadorMorreu() {
        return !jogador.estaVivo();
    }

    public Jogador getJogador() { return jogador; }
    public Inimigo getInimigo() { return inimigo; }
}
