package view;

import model.Inimigo;
import model.Jogador;
import model.PersonagemFactory;
import controller.Batalha;
import utils.SaveManager;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class GameScreen extends JFrame {

    private Jogador jogador;
    private Inimigo inimigoAtual;
    private Batalha batalha;

    private int playerWidth = 256;
    private int playerHeight = 256;

    private int enemyWidth = 256;
    private int enemyHeight = 256;

    private JLabel lblFundo;
    private JLabel lblVidaJogador;
    private JLabel lblVidaInimigo;
    private JProgressBar barraVidaJogador;
    private JProgressBar barraVidaInimigo;
    private JLabel lblPocoes;

    private JButton btnAtacar;
    private JButton btnPocao;

    private Image playerImage;
    private Image enemyImage;

    private Random rand = new Random();

    public GameScreen(Jogador jogador, Inimigo inimigoCarregado) {
        this.jogador = jogador;

        setTitle("RPG - Batalha");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        initComponents();

        if (inimigoCarregado != null) {
            this.inimigoAtual = inimigoCarregado;
            iniciarBatalhaComInimigoExistente();
        } else {
            gerarNovoInimigo();
        }
    }

    private ImageIcon ic(String nome) {
        try {
            ImageIcon raw = new ImageIcon(getClass().getResource("/imagens/" + nome));
            
             if (nome.equals("fundo.png")) {
                Image scaled = raw.getImage().getScaledInstance(790, 611, Image.SCALE_SMOOTH);
                     return new ImageIcon(scaled);
             
             }
            Image scaled = raw.getImage().getScaledInstance(256, 256, Image.SCALE_SMOOTH);
            return new ImageIcon(scaled);
        } catch (Exception e) {
            return null;
        }
    }

    private void initComponents() {

        lblFundo = new JLabel();
        ImageIcon fundo = ic("fundo.png");
        if (fundo != null) lblFundo.setIcon(fundo);
        lblFundo.setBounds(0, 0, 800, 600);
        lblFundo.setLayout(null);
        add(lblFundo);

        lblVidaJogador = new JLabel("Vida: " + jogador.getVida());
        lblVidaJogador.setForeground(Color.WHITE);
        lblVidaJogador.setBounds(20, 20, 200, 25);
        lblFundo.add(lblVidaJogador);

        barraVidaJogador = new JProgressBar(0, jogador.getVidaMax());
        barraVidaJogador.setValue(jogador.getVida());
        barraVidaJogador.setBounds(20, 50, 200, 20);
        lblFundo.add(barraVidaJogador);

        lblPocoes = new JLabel("Poções: " + jogador.getPotions());
        lblPocoes.setForeground(Color.WHITE);
        lblPocoes.setBounds(20, 80, 200, 20);
        lblFundo.add(lblPocoes);

        lblVidaInimigo = new JLabel("Vida: ---");
        lblVidaInimigo.setForeground(Color.WHITE);
        lblVidaInimigo.setBounds(600, 20, 200, 25);
        lblFundo.add(lblVidaInimigo);

        barraVidaInimigo = new JProgressBar();
        barraVidaInimigo.setBounds(580, 50, 200, 20);
        lblFundo.add(barraVidaInimigo);

        btnAtacar = new JButton("Atacar");
        btnAtacar.setBounds(330, 480, 140, 30);
        btnAtacar.addActionListener(e -> atacarInimigo());
        lblFundo.add(btnAtacar);

        btnPocao = new JButton("Beber Poção");
        btnPocao.setBounds(330, 520, 140, 30);
        btnPocao.addActionListener(e -> usarPocao());
        lblFundo.add(btnPocao);
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                SaveManager.salvarJogo(jogador, inimigoAtual);
            }
        });
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        int groundY = 600; 

        if (playerImage != null)
            g.drawImage(playerImage, 80, groundY - playerHeight, playerWidth, playerHeight, null);

        if (enemyImage != null)
            g.drawImage(enemyImage, 520, groundY - enemyHeight, enemyWidth, enemyHeight, null);
    }

    private void iniciarBatalhaComInimigoExistente() {
        batalha = new Batalha(jogador, inimigoAtual);

        ImageIcon icon = ic(inimigoAtual.getImagem());
        if (icon != null) enemyImage = icon.getImage();

        lblVidaInimigo.setText("Vida: " + inimigoAtual.getVida());
        
        barraVidaInimigo.setMaximum(inimigoAtual.getVida());
        barraVidaInimigo.setValue(inimigoAtual.getVida());

        ImageIcon imgJ = ic("begonia.png");
        if (imgJ != null) playerImage = imgJ.getImage();

        repaint();
        atualizarHUD();
    }

    private void gerarNovoInimigo() {
        int tipo = rand.nextInt(3);
        switch (tipo) {
            case 0 -> inimigoAtual = PersonagemFactory.criarInimigoFraco();
            case 1 -> inimigoAtual = PersonagemFactory.criarInimigoMedio();
            default -> inimigoAtual = PersonagemFactory.criarInimigoForte();
        }

        batalha = new Batalha(jogador, inimigoAtual);

        ImageIcon icon = ic(inimigoAtual.getImagem());
        if (icon != null) enemyImage = icon.getImage();

        lblVidaInimigo.setText("Vida: " + inimigoAtual.getVida());

        barraVidaInimigo.setMaximum(inimigoAtual.getVida());
        barraVidaInimigo.setValue(inimigoAtual.getVida());

        ImageIcon imgJ = ic("begonia.png");
        if (imgJ != null) playerImage = imgJ.getImage();

        repaint();
        atualizarHUD();
    }

    private void atacarInimigo() {
        int dano = batalha.turnoJogador();
        JOptionPane.showMessageDialog(this, jogador.getNome() + " causou " + dano + " de dano!");

        lblVidaInimigo.setText("Vida: " + inimigoAtual.getVida());
        barraVidaInimigo.setValue(inimigoAtual.getVida());

        if (batalha.inimigoMorreu()) {
            JOptionPane.showMessageDialog(this, "Você derrotou o inimigo!");
            eventoNarrativo();
            gerarNovoInimigo();
            return;
        }

        int danoInimigo = batalha.turnoInimigo();
        JOptionPane.showMessageDialog(this, inimigoAtual.getNome() + " causou " + danoInimigo + " de dano!");
        atualizarHUD();

        if (batalha.jogadorMorreu()) {
            JOptionPane.showMessageDialog(this, "Você morreu! Game Over");

            SaveManager.salvarJogo(jogador, inimigoAtual);
            System.exit(0);
        }

        repaint();
    }

    private void usarPocao() {
        if (jogador.getPotions() <= 0) {
            JOptionPane.showMessageDialog(this, "Você não tem mais poções!");
            return;
        }
        int resp = JOptionPane.showConfirmDialog(this,
                "Beber poção? (" + jogador.getPotions() + " restantes)",
                "Poção", JOptionPane.YES_NO_OPTION);

        if (resp == JOptionPane.YES_OPTION) {
            jogador.usarPocao();
            JOptionPane.showMessageDialog(this, "Curou 25 de vida!");
            atualizarHUD();
        }
    }

    private void atualizarHUD() {
        lblVidaJogador.setText("Vida: " + jogador.getVida());
        barraVidaJogador.setMaximum(jogador.getVidaMax());
        barraVidaJogador.setValue(jogador.getVida());

        lblPocoes.setText("Poções: " + jogador.getPotions());

        lblVidaInimigo.setText("Vida: " + inimigoAtual.getVida());
        barraVidaInimigo.setValue(inimigoAtual.getVida());
    }

    private void eventoNarrativo() {
        int evento = rand.nextInt(3);

        switch (evento) {

            case 0 -> {
                int e1 = JOptionPane.showConfirmDialog(this,
                        "Você encontrou uma cabana abandonada.\nDeseja entrar?",
                        "Cabana", JOptionPane.YES_NO_OPTION);
                if (e1 == JOptionPane.YES_OPTION) {
                    jogador.curar(7);
                    JOptionPane.showMessageDialog(this, "Encontrou erva mágica! Vida +7");
                }
            }

            case 1 -> {
                int e2 = JOptionPane.showConfirmDialog(this,
                        "Você econtrou um viajante que precisa de ajuda. Ajudar?",
                        "Viajante", JOptionPane.YES_NO_OPTION);
                if (e2 == JOptionPane.YES_OPTION) {
                    jogador.setAtaque(jogador.getAtaque() + 5);
                    JOptionPane.showMessageDialog(this, "Recebeu um amuleto! Vida +5");
                }
            }

            case 2 -> {
                int e3 = JOptionPane.showConfirmDialog(this,
                        "Uma poça de energia está aqui. Tocar?",
                        "Energia", JOptionPane.YES_NO_OPTION);
                if (e3 == JOptionPane.YES_OPTION) {
                    if (rand.nextBoolean()) {
                        jogador.receberDano(10);
                        JOptionPane.showMessageDialog(this, "Explodiu! Vida -10");
                    } else {
                        jogador.setDefesa(jogador.getDefesa() + 15);
                        JOptionPane.showMessageDialog(this, "Fortalecida! Vida +15");
                    }
                }
            }
        }

        atualizarHUD();
        repaint();
    }
}