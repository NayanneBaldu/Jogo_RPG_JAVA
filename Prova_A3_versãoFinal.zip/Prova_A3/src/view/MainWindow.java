package view;

import model.Inimigo;
import model.Jogador;
import model.PersonagemFactory;
import utils.SaveManager;

import javax.swing.*;

public class MainWindow extends JFrame {

    private JButton btnNovoJogo;
    private JButton btnCarregar;
    private JButton btnSair;
    private JLabel titulo;

    public MainWindow() {
        initComponents();
        mostrarIntro();
    }

    private void initComponents() {
        setTitle("RPG - Prova A3");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        titulo = new JLabel("RPG - Sistema A3");
        titulo.setBounds(90, 20, 220, 30);

        btnNovoJogo = new JButton("Iniciar Novo Jogo");
        btnNovoJogo.setBounds(110, 70, 180, 30);

        btnCarregar = new JButton("Carregar Jogo");
        btnCarregar.setBounds(110, 120, 180, 30);

        btnSair = new JButton("Sair");
        btnSair.setBounds(110, 170, 180, 30);

        add(titulo);
        add(btnNovoJogo);
        add(btnCarregar);
        add(btnSair);

        btnNovoJogo.addActionListener(e -> iniciarNovoJogo());
        btnCarregar.addActionListener(e -> carregarJogo());
        btnSair.addActionListener(e -> System.exit(0));
    }

    private void mostrarIntro() {
        String intro =
                "Nébulis, cidade de névoa e ecos.\n" +
                "O Coração da Aurora enfraqueceu, e Begonia chega para investigar.\n\n" +
                "Cada batalha revela um fragmento. Cada escolha altera o caminho.\n";
        JOptionPane.showMessageDialog(this, intro, "Introdução", JOptionPane.INFORMATION_MESSAGE);
    }

    private void iniciarNovoJogo() {
        String nome = JOptionPane.showInputDialog(this, "Digite o nome da personagem:");
        if (nome == null || nome.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nome inválido!");
            return;
        }
        Jogador novo = PersonagemFactory.criarJogadorPadrao(nome);
        this.dispose();
        
        new GameScreen(novo, null).setVisible(true);
    }

    private void carregarJogo() {
        Jogador j = SaveManager.carregarJogador();
        Inimigo i = SaveManager.carregarInimigo();

        if (j == null) {
            JOptionPane.showMessageDialog(this, "Nenhum jogo salvo encontrado.");
        } else {
            this.dispose();
            new GameScreen(j, i).setVisible(true);
        }
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> new MainWindow().setVisible(true));
    }
}