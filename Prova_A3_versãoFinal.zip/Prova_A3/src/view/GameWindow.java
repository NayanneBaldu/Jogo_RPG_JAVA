package view;

import javax.swing.*;

public class GameWindow extends JFrame {

    public GameWindow() {
        setTitle("RPG - Janela Principal");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JButton btnStart = new JButton("Iniciar Jogo");
        btnStart.setBounds(140, 120, 120, 30);
        btnStart.addActionListener(e -> {
            new MainWindow().setVisible(true);
            this.dispose();
        });

        add(btnStart);
    }
}
