package utils;

import model.Inimigo;
import model.Jogador;
import java.io.*;

public class SaveManager {

    private static final String SAVE_FILE = "save.txt";

    public static void salvarJogo(Jogador jogador, Inimigo inimigo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SAVE_FILE))) {
            writer.write(jogador.exportarDados());
            writer.newLine(); 
   
            if (inimigo != null) {
                writer.write(inimigo.exportarDados());
            }

        } catch (Exception e) {
            System.out.println("Erro ao salvar jogo: " + e.getMessage());
        }
    }

    public static Jogador carregarJogador() {
        try (BufferedReader reader = new BufferedReader(new FileReader(SAVE_FILE))) {
            String linha = reader.readLine(); 
            if (linha == null) return null;
            return Jogador.importarDados(linha);
        } catch (Exception e) {
            System.out.println("Erro ao carregar jogador: " + e.getMessage());
            return null;
        }
    }

    public static Inimigo carregarInimigo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(SAVE_FILE))) {
            reader.readLine(); 
            String linhaInimigo = reader.readLine(); 
            
            if (linhaInimigo == null) return null;
            
            return Inimigo.importarDados(linhaInimigo);
        } catch (Exception e) {
            System.out.println("Erro ao carregar inimigo: " + e.getMessage());
            return null;
        }
    }
}