package model;

public class Inimigo extends Personagem {

    private String imagem; 

    public Inimigo(String nome, int vida, int ataque, int defesa, String imagem) {
        super(nome, vida, ataque, defesa);
        this.imagem = imagem;
    }

    @Override
    public int atacar() {
        return this.ataque;
    }

    public String getImagem() {
        return imagem;
    }

    @Override
    public String toString() {
        return "Inimigo: " + nome + " | Vida: " + vida + " | Ataque: " + ataque + " | Defesa: " + defesa;
    }
public String exportarDados() {
    return nome + ";" + vida + ";" + ataque + ";" + defesa + ";" + imagem;
}

public static Inimigo importarDados(String linha) {
    String[] p = linha.split(";");
    if (p.length < 5) return null;

    String nome = p[0];
    int vida = Integer.parseInt(p[1]);
    int ataque = Integer.parseInt(p[2]);
    int defesa = Integer.parseInt(p[3]);
    String imagem = p[4];

    return new Inimigo(nome, vida, ataque, defesa, imagem);
}
}
