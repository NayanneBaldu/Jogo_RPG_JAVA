package model;

public class Jogador extends Personagem {

    private int potions = 3;      
    private final int MAX_POTIONS = 3;
    private int vidaMax;

public Jogador(String nome, int vidaMax, int ataque, int defesa) {
    super(nome, vidaMax, ataque, defesa);
    this.vidaMax = vidaMax;
    this.potions = 3;
}
public Jogador(String nome, int vidaAtual, int vidaMax, int ataque, int defesa, int potions) {
    super(nome, vidaAtual, ataque, defesa);
    this.vidaMax = vidaMax;
    this.potions = potions;
}

    @Override
    public int atacar() {
        return this.ataque;
    }

    public int atacar(Inimigo inimigo) {
        int dano = atacar();
        inimigo.receberDano(dano);
        return dano;
    }

   

    public void curar(int quantidade) {
        this.vida += quantidade;
        if (this.vida > vidaMax) this.vida = vidaMax;
    }

    public boolean podePegarPocao() {
        return potions < MAX_POTIONS;
    }

    public void pegarPocao() {
        if (podePegarPocao()) potions++;
    }

    public boolean usarPocao() {
        if (potions > 0) {
            potions--;
            curar(20);
            return true;
        }
        return false;
    }

    public int getPotions() { return potions; }
    public int getVidaMax() { return vidaMax; }

    
    public String exportarDados() {
        return nome + ";" + vida + ";" + vidaMax + ";" + ataque + ";" + defesa + ";" + potions;
    }

    public static Jogador importarDados(String linha) {
        String[] p = linha.split(";");
        if (p.length < 6) return null;

        String nome = p[0];
        int vidaAtual = Integer.parseInt(p[1]);
        int vidaMax = Integer.parseInt(p[2]);
        int ataque = Integer.parseInt(p[3]);
        int defesa = Integer.parseInt(p[4]);
        int potions = Integer.parseInt(p[5]);

        return new Jogador(nome,vidaAtual, vidaMax, ataque, defesa, potions );
    }
}
