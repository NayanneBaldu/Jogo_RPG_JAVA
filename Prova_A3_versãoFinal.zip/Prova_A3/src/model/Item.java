package model;

public interface Item {
    void usar(Jogador jogador);
}
