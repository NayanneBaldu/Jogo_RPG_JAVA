package model;

public class PersonagemFactory {

    public static Jogador criarJogadorPadrao(String nome) {
        return new Jogador(nome, 100, 100, 20, 10, 3);  
    }

    public static Inimigo criarInimigoFraco() {
        return new Inimigo("Goblin", 50, 10, 3, "goblin.png");
    }

    public static Inimigo criarInimigoMedio() {
        return new Inimigo("Lobo", 80, 15, 5, "lobo.png");
    }

    public static Inimigo criarInimigoForte() {
        return new Inimigo("Ogro de Pedra", 120, 25, 8, "ogro_de_pedra.png");
    }
}
