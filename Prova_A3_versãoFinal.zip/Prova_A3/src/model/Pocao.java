package model;

public class Pocao implements Item {

    private int cura;
    private String imagem; 

    public Pocao(int cura) {
        this.cura = cura;
    }

    public Pocao(int cura, String imagem) {
        this.cura = cura;
        this.imagem = imagem;
    }

    @Override
    public void usar(Jogador jogador) {
        jogador.curar(cura);
    }

    public int getCura() { return cura; }
    public String getImagem() { return imagem; }
}
